	uSync.BackOffice -> uSync
	-------------------------

	For strange and historical reasonse uSync.Backoffice is actually the same 
	package as uSync. to avoid confusion (mainly caused by me) I will be 
	phasing the nuget uSync.BackOffice package out. Please where possible
	use the main uSync package. 
	
	